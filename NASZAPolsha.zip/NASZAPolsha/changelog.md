CHANGELOG
=======

* unset all thumbnail sizes: 

-thumbnail: 480×270 pixels (proportionally resized to fit inside dimensions)
-medium: 480×270 pixels (proportionally resized to fit inside dimensions)
-medium_large: 768×0 pixels (proportionally resized to fit inside dimensions)
-large: 480×270 pixels (proportionally resized to fit inside dimensions)
-1536x1536: 1536×1536 pixels (proportionally resized to fit inside dimensions)
-2048x2048: 2048×2048 pixels (proportionally resized to fit inside dimensions)
-post-thumbnail: 672×9999 pixels (proportionally resized to fit inside dimensions)
-kleo-full-width: 1038×9999 pixels (proportionally resized to fit inside dimensions)
-woocommerce_thumbnail: 300×0 pixels (proportionally resized to fit inside dimensions)
-woocommerce_single: 600×0 pixels (proportionally resized to fit inside dimensions)
-woocommerce_gallery_thumbnail: 100×100 pixels (cropped to fit)
-shop_catalog: 300×0 pixels (proportionally resized to fit inside dimensions)
-shop_single: 600×0 pixels (proportionally resized to fit inside dimensions)
-shop_thumbnail: 100×100 pixels (cropped to fit)