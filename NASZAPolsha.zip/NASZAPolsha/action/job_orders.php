<?php

require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
echo job_order_activation_do_this();