<?php

require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
//$mata = get_post_meta(15747);
$mata = get_post_meta(15746);
print_a($mata);