<?php

echo '<div class="search_form_archive">' . do_shortcode('[kleo_search_form context="job" placeholder="Шукати"]') . '</div>';
